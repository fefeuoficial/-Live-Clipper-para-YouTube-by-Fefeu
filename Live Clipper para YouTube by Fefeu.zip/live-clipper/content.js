(() => {
  const MAX_MS = 3 * 60 * 1000; // limite de 3 minutos
  const LIGHT_KEY = "lcLightMode";
  const HEALTH_CHECK_MS = 4000; // se não chegar nenhum dado em 4s, troca de formato

  const MIME_CANDIDATES = [
    "video/mp4;codecs=avc1,mp4a.40.2",
    "video/mp4;codecs=avc1,opus",
    "video/mp4",
    "video/webm;codecs=h264,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm;codecs=vp9,opus",
    "video/webm"
  ];

  let recorder = null;
  let chunks = [];
  let startedAt = 0;
  let tickId = null;
  let stopTimeoutId = null;
  let healthId = null;
  let drawRafId = null;
  let userStopped = false;
  let mimeQueue = [];
  let lightMode = false;

  try { lightMode = localStorage.getItem(LIGHT_KEY) === "1"; } catch (_) {}

  const getVideo = () => document.querySelector("video.html5-main-video") || document.querySelector("video");
  const fmt = (ms) => {
    const s = Math.floor(ms / 1000);
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  };

  function toast(msg) {
    const player = document.querySelector("#movie_player");
    if (!player) return;
    document.getElementById("lc-toast")?.remove();
    const el = document.createElement("div");
    el.id = "lc-toast";
    el.textContent = msg;
    player.appendChild(el);
    setTimeout(() => el.remove(), 4500);
  }

  function updateButton() {
    const btn = document.getElementById("lc-btn");
    if (!btn) return;
    if (recorder) {
      btn.classList.add("lc-recording");
      btn.textContent = `⏹ ${fmt(Date.now() - startedAt)} / ${fmt(MAX_MS)}`;
      btn.title = "Parar e salvar clipe";
    } else {
      btn.classList.remove("lc-recording");
      btn.textContent = lightMode ? "✂ Clipar (leve)" : "✂ Clipar";
      btn.title = "Gravar clipe (máx. 3 min). Clique com o botão direito para alternar o modo leve (720p/30fps).";
    }
  }

  function toggleLightMode(e) {
    e.preventDefault();
    if (recorder) return;
    lightMode = !lightMode;
    try { localStorage.setItem(LIGHT_KEY, lightMode ? "1" : "0"); } catch (_) {}
    updateButton();
    toast(lightMode
      ? "Modo leve ativado: 720p a 30fps (menos travamentos)."
      : "Modo normal: qualidade original do player.");
  }

  // Modo leve: redesenha o vídeo num canvas 720p a 30fps e grava o canvas
  function buildLightStream(video, srcStream) {
    const h = Math.min(720, video.videoHeight || 720);
    const w = Math.round(h * ((video.videoWidth || 1280) / (video.videoHeight || 720)));
    const canvas = document.createElement("canvas");
    canvas.width = w - (w % 2);
    canvas.height = h - (h % 2);
    const ctx = canvas.getContext("2d", { alpha: false });

    const interval = 1000 / 30;
    let last = 0;
    const draw = (t) => {
      drawRafId = requestAnimationFrame(draw);
      if (t - last < interval) return;
      last = t;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    };
    drawRafId = requestAnimationFrame(draw);

    const out = canvas.captureStream(30);
    srcStream.getAudioTracks().forEach((tr) => out.addTrack(tr));
    return out;
  }

  function detach(rec) {
    if (!rec) return;
    rec.ondataavailable = null;
    rec.onstop = null;
    rec.onerror = null;
    try { if (rec.state !== "inactive") rec.stop(); } catch (_) {}
  }

  function resetState() {
    clearInterval(tickId);
    clearTimeout(stopTimeoutId);
    clearTimeout(healthId);
    cancelAnimationFrame(drawRafId);
    recorder = null;
    chunks = [];
    updateButton();
  }

  // Tenta gravar com o próximo formato da fila; se um falhar, passa para o seguinte
  function tryNextFormat(video, reason) {
    if (reason) console.warn("[Live Clipper] trocando de formato:", reason);

    detach(recorder);
    cancelAnimationFrame(drawRafId);
    clearTimeout(healthId);
    chunks = [];

    if (!mimeQueue.length) {
      resetState();
      toast("Não foi possível gravar este vídeo. Veja o console (F12) para detalhes.");
      return;
    }

    const mime = mimeQueue.shift();
    let rec;
    try {
      const srcStream = video.captureStream();
      const stream = lightMode ? buildLightStream(video, srcStream) : srcStream;
      const height = lightMode ? 720 : (video.videoHeight || 720);
      const videoBitsPerSecond = height >= 1080 ? 5_000_000 : height >= 720 ? 3_500_000 : 2_000_000;
      rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond, audioBitsPerSecond: 128_000 });
    } catch (e) {
      recorder = null;
      return tryNextFormat(video, `${mime}: ${e.message}`);
    }

    recorder = rec;
    rec.ondataavailable = (e) => {
      if (rec === recorder && e.data && e.data.size > 0) chunks.push(e.data);
    };
    rec.onerror = (e) => {
      if (rec !== recorder) return;
      console.error("[Live Clipper] erro do MediaRecorder:", e.error || e);
      if (!chunks.length && !userStopped) tryNextFormat(video, `${mime}: erro do gravador`);
    };
    rec.onstop = () => {
      if (rec !== recorder) return;
      if (userStopped || chunks.length) saveClip();
      else tryNextFormat(video, `${mime}: parou sem gerar dados`);
    };

    try {
      rec.start(1000);
    } catch (e) {
      recorder = null;
      return tryNextFormat(video, `${mime}: ${e.message}`);
    }

    // Se nenhum dado chegar em alguns segundos, esse formato não está funcionando
    healthId = setTimeout(() => {
      if (rec === recorder && !chunks.length && !userStopped) {
        tryNextFormat(video, `${mime}: nenhum dado após ${HEALTH_CHECK_MS / 1000}s`);
      }
    }, HEALTH_CHECK_MS);
  }

  function startRecording() {
    const video = getVideo();
    if (!video || !video.captureStream) {
      toast("Não foi possível capturar este vídeo.");
      return;
    }
    if (video.paused) {
      toast("O vídeo está pausado. Dê play antes de clipar.");
      return;
    }
    if (video.muted || video.volume === 0) {
      toast("Atenção: com o player mudo, o clipe sai sem áudio.");
    }

    userStopped = false;
    mimeQueue = MIME_CANDIDATES.filter((m) => MediaRecorder.isTypeSupported(m));
    mimeQueue.push(""); // último recurso: formato padrão do navegador

    startedAt = Date.now();
    tickId = setInterval(updateButton, 500);
    stopTimeoutId = setTimeout(stopRecording, MAX_MS);

    tryNextFormat(video);
    updateButton();
  }

  function stopRecording() {
    if (!recorder) return;
    userStopped = true;
    clearInterval(tickId);
    clearTimeout(stopTimeoutId);
    clearTimeout(healthId);
    cancelAnimationFrame(drawRafId);
    try {
      if (recorder.state !== "inactive") {
        recorder.requestData();
        recorder.stop();
      } else {
        saveClip();
      }
    } catch (e) {
      console.error("[Live Clipper]", e);
      saveClip();
    }
  }

  function saveClip() {
    const mime = (recorder && recorder.mimeType) || "video/webm";
    const isMp4 = mime.startsWith("video/mp4");
    const blob = new Blob(chunks, { type: isMp4 ? "video/mp4" : "video/webm" });
    const seconds = Math.round((Date.now() - startedAt) / 1000);
    resetState();

    if (blob.size === 0) {
      toast("Clipe vazio. Veja o console (F12) para detalhes.");
      return;
    }

    const title = document.title
      .replace(/ - YouTube$/, "")
      .replace(/[^\w\-áéíóúâêôãõçÁÉÍÓÚÂÊÔÃÕÇ ]+/g, "")
      .trim()
      .slice(0, 60) || "clipe";
    const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title} - ${stamp}.${isMp4 ? "mp4" : "webm"}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60_000);

    toast(isMp4
      ? `Clipe de ${seconds}s salvo em MP4!`
      : `Clipe de ${seconds}s salvo em WebM (o MP4 não funcionou neste vídeo).`);
  }

  function ensureButton() {
    const controls = document.querySelector(".ytp-right-controls");
    if (!controls || document.getElementById("lc-btn")) return;
    const btn = document.createElement("button");
    btn.id = "lc-btn";
    btn.className = "ytp-button";
    btn.addEventListener("click", () => (recorder ? stopRecording() : startRecording()));
    btn.addEventListener("contextmenu", toggleLightMode);
    controls.prepend(btn);
    updateButton();
  }

  // O YouTube é uma SPA: garante o botão após navegações
  setInterval(ensureButton, 1000);

  // Para e salva se o usuário mudar de vídeo durante a gravação
  window.addEventListener("yt-navigate-start", stopRecording);

  // Atalho: Alt+C
  document.addEventListener("keydown", (e) => {
    if (e.altKey && e.key.toLowerCase() === "c") {
      e.preventDefault();
      recorder ? stopRecording() : startRecording();
    }
  });
})();
