# Live Clipper para YouTube by Fefeu

## Instalar
1. Abra `chrome://extensions`
2. Ative o **Modo do desenvolvedor**
3. Clique em **Carregar sem compactação** e selecione a pasta `live-clipper`
4. Abra uma live no YouTube e recarregue a página

## Usar
- Clique em **✂ Clipar** na barra de controles do player (ou Alt+C) para começar.
- Clique de novo para parar e baixar. Para sozinho aos 3:00.
- O clipe é baixado automaticamente em `.mp4` (em Chromes muito antigos, sem suporte a MP4, cai para `.webm`).
- Se travar em 1080p: clique com o botão direito em **✂ Clipar** para ativar o **modo leve** (720p a 30fps). Clique direito de novo para voltar ao normal.
